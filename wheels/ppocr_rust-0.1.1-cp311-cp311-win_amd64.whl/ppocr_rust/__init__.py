from .ppocr_rust import *

__doc__ = ppocr_rust.__doc__
if hasattr(ppocr_rust, "__all__"):
    __all__ = ppocr_rust.__all__