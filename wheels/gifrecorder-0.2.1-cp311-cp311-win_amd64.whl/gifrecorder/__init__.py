from .gifrecorder import *

__doc__ = gifrecorder.__doc__
if hasattr(gifrecorder, "__all__"):
    __all__ = gifrecorder.__all__