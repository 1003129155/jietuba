from .windows_media_ocr import *

__doc__ = windows_media_ocr.__doc__
if hasattr(windows_media_ocr, "__all__"):
    __all__ = windows_media_ocr.__all__