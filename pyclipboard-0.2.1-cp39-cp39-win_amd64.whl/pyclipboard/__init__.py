from .pyclipboard import *

__doc__ = pyclipboard.__doc__
if hasattr(pyclipboard, "__all__"):
    __all__ = pyclipboard.__all__